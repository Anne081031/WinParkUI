﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;

namespace odm.ui.controls.GraphEditor {
	public class ObjectTrackerDM355 :Control {

		public int BinaryNet { get; set; }
	}
}
