﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace odm
{
	/// <summary>
	/// Interaction logic for RecorderCtrl.xaml
	/// </summary>
	public partial class RecorderCtrl : UserControl
	{
		public RecorderCtrl()
		{
			this.InitializeComponent();
		}

		private void Button_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			// TODO: Add event handler implementation here.
		}
	}
}