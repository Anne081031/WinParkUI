﻿using System;
using System.Collections.Generic;
using System.Text;

namespace odm
{
    /// <summary>
    /// Class containing global strings
    /// </summary>
    internal static class Globals
    {
        internal const string UnitTestSymbol = "UNIT_TESTS";
    }
}
