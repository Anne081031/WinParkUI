﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace odm.ui.core {
	public class TLSManager {
		public static bool UseTls(Uri[] uris) {
			bool useTls = false;

			return useTls;
		}
	}
}
