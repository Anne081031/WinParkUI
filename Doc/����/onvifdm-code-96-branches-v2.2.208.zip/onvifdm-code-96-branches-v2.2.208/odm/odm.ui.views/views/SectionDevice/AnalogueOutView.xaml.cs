﻿
namespace odm.ui.controls {
	/// <summary>
	/// Interaction logic for PropertyAnalogueOut.xaml
	/// </summary>
	public partial class PropertyAnalogueOut : BasePropertyControl {
		public PropertyAnalogueOut() {
			InitializeComponent();
		}
		//LinkButtonsStrings titles = new LinkButtonsStrings();
	}
}
