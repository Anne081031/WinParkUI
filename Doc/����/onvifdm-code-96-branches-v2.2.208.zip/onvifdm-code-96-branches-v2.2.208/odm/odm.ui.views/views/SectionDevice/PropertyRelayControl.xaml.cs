﻿
namespace odm.ui.controls {
	public partial class PropertyRelayControl : BasePropertyControl {
		public PropertyRelayControl() {
			InitializeComponent();
		}
		LinkButtonsStrings titles = new LinkButtonsStrings();
	}
}
